USE HOTEL;

SELECT * FROM T2_Rooms WHERE Room_location='block-2';

SELECT * FROM T2_CUSTOMER_ADDRESS WHERE Customer_ID='3';


SELECT * FROM T2_Billing WHERE Room_charge > '2500';

SELECT * FROM T2_Reservation WHERE Number_of_guests > '3';

SELECT * FROM T2_Customer WHERE Zipcode < '534203';

SELECT * FROM T2_CUSTOMER_ADDRESS WHERE Customer_ID < '4';

SELECT * FROM T2_SERVICES WHERE Reservation_number >= '2';

SELECT Customer_ID, Reservation_number FROM T2_Reservation WHERE Check_in_date >= '1999-02-03';

SELECT  Customer_Name FROM T2_Customer WHERE Customer_ID <= '3'; 
SELECT * FROM emp_info WHERE age<=35;

SELECT * FROM emp_info WHERE empname <> 'Jax';
SELECT * FROM T2_Rooms WHERE Room_Type <> 'Deluxe';