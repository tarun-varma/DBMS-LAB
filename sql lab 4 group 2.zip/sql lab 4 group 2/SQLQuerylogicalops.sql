SELECT * FROM T2_SERVICES WHERE Service_cost > '2000' AND Service_ID >= 2; 
SELECT * FROM T2_Rooms WHERE number_of_beds = '1' AND Room_location = 'block-2';

SELECT Reservation_number FROM T2_Reservation WHERE Reservation_date > '1999-02-02' OR Room_number = '1';
SELECT Customer_ID FROM T2_CUSTOMER_ADDRESS WHERE Street='JS Nagar' OR DNO = '9-12';

SELECT * FROM T2_Customer WHERE City IN ('hyderabad', 'Bengaluru');
SELECT * FROM T2_Billing WHERE Payment_date IN('2021-05-05');

SELECT * FROM T2_Reservation WHERE NOT Reservation_number = '2';
SELECT * FROM Customer_Backup WHERE NOT Customer_Name='Lofflin';

SELECT empname FROM emp_info WHERE AGE BETWEEN 25 AND 70;
SELECT Service_ID,Service_name,Service_cost FROM T2_SERVICES WHERE Reservation_number BETWEEN 2 AND 3;