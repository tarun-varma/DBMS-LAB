USE HOTEL;

SELECT CONCAT(DNO,',',Street,',',City,',',State) AS Customer_permanent_address FROM T2_CUSTOMER_ADDRESS;

SELECT CONCAT(Room_number,',',Room_location,',') AS Room_address FROM T2_Rooms;

SELECT empname AS Waiters FROM emp_info WHERE Salary<7000;