use HOTEL;

SELECT Customer_Name FROM T2_Customer WHERE Customer_ID IN (SELECT Customer_ID from T2_Billing WHERE Room_charge>=5000);

SELECT CONCAT(Check_in_date,',',Check_out_date) AS Stay_in_hotel FROM T2_Reservation WHERE Room_number IN  
(SELECT Room_number FROM T2_Rooms WHERE Room_Type='Deluxe');


SELECT Reservation_date FROM T2_Reservation WHERE Reservation_number IN (SELECT Reservation_number FROM T2_SERVICES WHERE Service_cost > 3000);


SELECT Customer_Name FROM T2_Customer WHERE Customer_ID IN
(SELECT Customer_ID FROM T2_Rooms WHERE Room_number IN 
(SELECT Room_number FROM T2_Reservation));

SELECT COUNT(Customer_ID) AS Ordered_customers FROM T2_Reservation WHERE  Reservation_number IN (SELECT Reservation_number FROM T2_SERVICES);