USE HOTEL;
INSERT INTO T2_Customer
VALUES('1','Lofflin','8688543748','Nagpur','MP','534201','loff@gmail.com');

INSERT INTO T2_Customer
VALUES('2','Ram','8688543744','hyderabad','TN','534204','Ram@gmail.com');

INSERT INTO T2_Customer
VALUES('3','Mahesh','8688543746','Lucknow','UP','534205','mah@gmail.com');

INSERT INTO T2_Customer
VALUES('4','Prabha','8688543766','Bengaluru','Karnataka','534201','prab@gmail.com');



INSERT INTO T2_CUSTOMER_ADDRESS(Customer_ID,Street,DNO,City,State)
VALUES('1','RP NAGAR','7-11','Nagpur','Madhya pradesh');

INSERT INTO T2_CUSTOMER_ADDRESS(Customer_ID,Street,DNO,City,State)
VALUES('2','Sriram nagar','9-12','hyderabad','Telengana');

INSERT INTO T2_CUSTOMER_ADDRESS(Customer_ID,Street,DNO,City,State)
VALUES('3','JS Nagar','7-13','Lucknow','Utter pradesh');

INSERT INTO T2_CUSTOMER_ADDRESS(Customer_ID,Street,DNO,City,State)
VALUES('4','Indira NAGAR','7-8-12','Bengaluru','Karnataka');

INSERT INTO Customer_Backup SELECT * FROM T2_Customer;

INSERT INTO emp_info
VALUES('1','Max','1999/03/21');
INSERT INTO emp_info
VALUES('2','Jax','1959/04/5');
INSERT INTO emp_info
VALUES('3','Nax','1992/07/7');

INSERT INTO T2_Billing
VALUES('1','2000','1234567891','2021/09/5','1');

INSERT INTO T2_Billing
VALUES('2','5000','9876543211','2021/05/5','2');

INSERT INTO T2_Billing
VALUES('3','6000','1234987655','2021/09/30','3');

INSERT INTO T2_Billing
VALUES('4','3000','5546666666','2021/12/11','4');

INSERT INTO T2_Rooms
VALUES('1','Deluxe','block-2','2','2');

INSERT INTO T2_Rooms
VALUES('2','Economic','block-1','3','1');

INSERT INTO T2_Rooms
VALUES('3','Deluxe','block-2','1','4');



INSERT INTO T2_Reservation
VALUES('1','1999/02/3','1999/02/22','5','1999/02/1','2','1');

INSERT INTO T2_Reservation
VALUES('2','1999/02/3','1999/02/22','4','1999/02/3','1','2');

INSERT INTO T2_Reservation
VALUES('3','1999/04/3','1999/04/4','2','1999/04/1','4','3');

INSERT INTO T2_SERVICES
VALUES('1','Food','3000','1');

INSERT INTO T2_SERVICES
VALUES('2','Transport','8000','3');

INSERT INTO T2_SERVICES
VALUES('3','Room','4000','2');


