SELECT * FROM T2_SERVICES;
SELECT * FROM T2_Rooms WHERE Room_Type='Deluxe';
SELECT Customer_Name FROM T2_Customer;
SELECT Service_name,Service_cost FROM T2_SERVICES WHERE Service_ID='2';
SELECT DNO,Street,City,State FROM T2_CUSTOMER_ADDRESS;