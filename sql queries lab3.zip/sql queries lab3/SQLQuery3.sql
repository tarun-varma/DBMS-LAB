USE HOTEL;

INSERT  INTO T2_Customer
VALUES ('1','Rishi','8543267899','Ghaziabad','UP','534286','abc@gmail.com');

INSERT INTO T2_Customer
VALUES ('5','Ravi','8688543746','Vizag','AP','534211','ravi@gamil.com');

INSERT INTO T2_Customer(Customer_ID,Phone_number,City,State,Zipcode,Email_ID)
VALUES ('5','9885249328','Agra','UP','586214','mis@gmail.com');