INSERT INTO T2_CUSTOMER_ADDRESS
VALUES('6','HSR Layout','9-18-07','Bengaluru','Karnataka');