
CREATE PROCEDURE Check_out_list @input date
AS
SELECT * FROM T2_Reservation WHERE Check_out_date = @input;
GO

CREATE PROCEDURE Selectemployeebyname @emp_name varchar(max), @emp_salary int
AS
SELECT * FROM emp_info WHERE empname = @emp_name AND Salary = @emp_salary;
GO

EXEC Check_out_list @input = '1999-02-22';
EXEC Selectemployeebyname @emp_name='Jax', @emp_salary=10000;