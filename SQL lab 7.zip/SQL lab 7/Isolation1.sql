USE HOTEL;
GO

BEGIN TRANSACTION

UPDATE emp_info SET empname='Rayudu' WHERE empid=2;
