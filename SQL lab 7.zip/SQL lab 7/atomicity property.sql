USE HOTEL;
GO

BEGIN TRANSACTION 

UPDATE T2_Customer SET Email_ID='rocketraja@gmail.com' WHERE Customer_Name='Gaikwad'

INSERT INTO T2_Customer 
VALUES('Ali',123456788,'chennai','Tamilnadu',534674,'valimaiupdate@gmail.com')

COMMIT TRANSACTION

SELECT * FROM T2_Customer
