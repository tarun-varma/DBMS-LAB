USE HOTEL;
EXEC sp_help T2_Rooms