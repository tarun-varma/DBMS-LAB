SELECT 
    *
FROM
    information_schema.tables;