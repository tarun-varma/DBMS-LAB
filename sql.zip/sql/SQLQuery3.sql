USE HOTEL;

CREATE TABLE T2_Customer(
	Customer_ID INT PRIMARY KEY NOT NULL,
	Customer_Name VARCHAR(30) NOT NULL,
	Phone_number VARCHAR(12) NOT NULL,
	City CHAR(20) NOT NULL,
	State CHAR(20) NOT NULL,
	Zipcode INT NOT NULL,
	Email_ID VARCHAR(50), 
);



CREATE TABLE T2_Rooms
(
	Room_number INT PRIMARY KEY NOT NULL,
	Room_Type VARCHAR(10) NOT NULL,
	Room_location VARCHAR(10) NOT NULL,
	number_of_beds INT NOT NULL,
	Customer_ID INT FOREIGN KEY REFERENCES T2_Customer(Customer_ID) NOT NULL
);

CREATE TABLE T2_Reservation(
	Reservation_number INT PRIMARY KEY NOT NULL,
	Check_in_date DATE NOT NULL,
	Check_out_date DATE NOT NULL,
	Number_of_guests INT NOT NULL,
	Reservation_date DATE NOT NULL,
	Customer_ID INT FOREIGN KEY REFERENCES T2_Customer(Customer_ID) NOT NULL,
	Room_number INT FOREIGN KEY REFERENCES T2_Rooms(Room_number) NOT NULL
);

CREATE TABLE T2_SERVICES(
	Service_ID INT PRIMARY KEY NOT NULL,
	Service_name CHAR(20) NOT NULL,
	Service_cost INT NOT NULL,
	Reservation_number INT FOREIGN KEY REFERENCES T2_Reservation(Reservation_number) NOT NULL
);

CREATE TABLE T2_Billing(
	Billing_# INT PRIMARY KEY NOT NULL,
	Room_charge INT NOT NULL,
	Credit_card VARCHAR(10) NOT NULL,
	Payment_date DATE NOT NULL,
	Customer_ID INT FOREIGN KEY REFERENCES T2_Customer(Customer_ID) NOT NULL
);

CREATE TABLE T2_CUSTOMER_ADDRESS(
	Customer_ID INT PRIMARY KEY FOREIGN KEY REFERENCES T2_Customer(Customer_ID) NOT NULL,
	Street VARCHAR(50) NOT NULL,
	DNO VARCHAR(50) NOT NULL,
	Zipcode INT NOT NULL,
	City CHAR(20) NOT NULL,
	State CHAR(20) NOT NULL,
);