USE HOTEL;

CREATE TABLE emp_info(
	empid SMALLINT PRIMARY KEY NOT NULL,
	empname VARCHAR(MAX),
	dob date,
	age AS DATEDIFF(YEAR,dob,GETDATE())
);