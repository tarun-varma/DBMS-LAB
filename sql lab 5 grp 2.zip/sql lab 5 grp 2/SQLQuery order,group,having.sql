USE HOTEL;

----------------ORDERBY---------------------

SELECT * FROM T2_Customer ORDER BY Customer_Name ASC;
SELECT * FROM emp_info ORDER BY age DESC;

---------------GROUPBY-------------------
SELECT number_of_beds, COUNT(*) AS number_of_rooms FROM T2_Rooms GROUP BY number_of_beds;
SELECT Zipcode,COUNT(*) FROM T2_Customer GROUP BY Zipcode;

-------------------HAVING---------------
SELECT COUNT(Room_number),Room_Type FROM T2_Rooms GROUP BY Room_Type HAVING COUNT(Room_number) >= 1;
SELECT COUNT(Reservation_number), LEFT(Reservation_date,4) FROM T2_Reservation GROUP BY LEFT(Reservation_date,4) HAVING COUNT(Reservation_number) >= 1;
