--------------------INNER JOIN------------------
SELECT Customer_Name,DNO,Street,T2_Customer.City FROM T2_Customer
INNER JOIN
T2_CUSTOMER_ADDRESS
ON T2_Customer.Customer_ID = T2_CUSTOMER_ADDRESS.Customer_ID;

SELECT Customer_Name,Number_of_guests,Check_in_date,Check_out_date FROM T2_Customer
INNER JOIN T2_Reservation
ON T2_Customer.Customer_ID = T2_Reservation.Customer_ID;

SELECT Reservation_number,Reservation_date,Room_Type,Room_location FROM T2_Rooms INNER JOIN T2_Reservation
ON T2_Rooms.Room_number = T2_Reservation.Room_number;

----------LEFT OUTER JOIN---------
SELECT * FROM T2_Customer
LEFT OUTER JOIN T2_Rooms
ON T2_Customer.Customer_ID = T2_Rooms.Customer_ID;

SELECT * FROM T2_CUSTOMER_ADDRESS
LEFT OUTER JOIN T2_Reservation
ON T2_Reservation.Customer_ID = T2_CUSTOMER_ADDRESS.Customer_ID;

SELECT * FROM emp_info LEFT OUTER JOIN
T2_SERVICES ON
T2_SERVICES.Service_ID = emp_info.empid;
------RIGHT OUTER JOIN------
SELECT * FROM T2_Rooms
RIGHT OUTER JOIN T2_Customer
ON T2_Customer.Customer_ID = T2_Rooms.Customer_ID;

SELECT * FROM T2_Reservation
RIGHT OUTER JOIN T2_CUSTOMER_ADDRESS
ON T2_Reservation.Customer_ID = T2_CUSTOMER_ADDRESS.Customer_ID;

SELECT * FROM T2_SERVICES RIGHT OUTER JOIN
emp_info ON
T2_SERVICES.Service_ID = emp_info.empid;