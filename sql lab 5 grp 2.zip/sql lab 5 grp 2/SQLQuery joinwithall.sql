USE HOTEL;

SELECT COUNT(*) ,Room_location FROM T2_Rooms 
JOIN T2_Reservation
ON T2_Rooms.Customer_ID = T2_Reservation.Customer_ID
JOIN T2_Customer
ON T2_Rooms.Customer_ID = T2_Customer.Customer_ID
GROUP BY Room_location
HAVING Room_location LIKE 'block%'
ORDER BY Room_location DESC;