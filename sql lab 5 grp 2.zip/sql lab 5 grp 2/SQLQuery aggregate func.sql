USE HOTEL;

SELECT AVG(age) AS average_age FROM emp_info;

SELECT MAX(number_of_beds) AS Max_numofbeds FROM T2_Rooms;

SELECT MIN(Service_cost) AS min_service_charge FROM T2_SERVICES;

SELECT COUNT(Customer_ID) from T2_customer where Customer_Name LIKE '%a%';

SELECT SUM(Room_charge) AS total_charges FROM T2_Billing;