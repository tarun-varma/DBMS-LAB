SELECT Customer_Name,COUNT(*) FROM T2_Customer 
WHERE Customer_ID = ANY(
						SELECT Customer_ID from T2_Reservation 
						WHERE Reservation_number = ANY(
													   SELECT Reservation_number FROM T2_SERVICES
													   WHERE Service_cost >= 4000
													   )
						)
GROUP BY Customer_Name HAVING Customer_Name LIKE '%a%'
ORDER BY Customer_Name desc;