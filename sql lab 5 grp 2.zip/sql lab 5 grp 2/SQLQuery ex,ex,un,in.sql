----------EXCEPT---------------
SELECT Customer_ID FROM T2_Customer
EXCEPT
SELECT Customer_ID FROM T2_Reservation;
----------EXISTS--------------
SELECT Customer_ID FROM T2_Rooms
WHERE EXISTS
(SELECT Customer_ID FROM T2_Billing)
ORDER BY Customer_ID ASC;
---------NOT EXISTS--------------
SELECT * FROM T2_Customer
WHERE NOT EXISTS
(SELECT Customer_ID FROM T2_Reservation);
---------UNION--------------
SELECT City FROM T2_CUSTOMER_ADDRESS
UNION
SELECT City FROM T2_Customer;
--------INTERSECTION----------
SELECT Room_charge FROM T2_Billing
INTERSECT
SELECT Service_cost FROM T2_SERVICES;