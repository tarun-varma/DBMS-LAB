USE HOTEL;
-----------------"ANY"------------------
SELECT * FROM T2_Customer WHERE Customer_ID <= ANY(SELECT Customer_ID FROM T2_Rooms WHERE Customer_ID < 3)

SELECT * FROM T2_Rooms WHERE number_of_beds < ANY(SELECT Number_of_guests FROM T2_Reservation);

SELECT Service_name,Service_cost FROM T2_SERVICES WHERE Service_ID >= ANY(SELECT empid FROM emp_info WHERE age > 25);

------------------------"ALL"-----------------------------------------

SELECT Customer_Name FROM T2_Customer WHERE Customer_ID <= ALL(SELECT Customer_ID FROM T2_Billing WHERE Room_charge >= 3000);

SELECT* FROM T2_SERVICES WHERE Reservation_number <= ALL(SELECT Reservation_number FROM T2_Reservation WHERE Reservation_date > '1999-01-01');

SELECT * FROM T2_CUSTOMER_ADDRESS WHERE Customer_ID < ALL(SELECT Customer_ID FROM T2_Rooms WHERE Room_Type = 'Deluxe');

-----------------------"LIKE"---------------------------------------------

SELECT * FROM T2_CUSTOMER_ADDRESS WHERE DNO LIKE '7-%';
SELECT empname,Salary FROM emp_info WHERE empname LIKE '%a%';
SELECT * FROM T2_CUSTOMER_ADDRESS WHERE Street LIKE '%nagar';

----------------------DIFFERENCE BETWEEN ANY AND ALL--------------------
SELECT Customer_Name FROM T2_Customer WHERE Customer_ID <= ALL(SELECT Customer_ID FROM T2_Billing WHERE Room_charge >= 3000);

SELECT Customer_Name FROM T2_Customer WHERE Customer_ID <= ANY(SELECT Customer_ID FROM T2_Billing WHERE Room_charge >= 3000);