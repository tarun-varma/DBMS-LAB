USE joindb;

SELECT Orders.OrderID, Customers.CustomerName, Shippers.ShipperName
FROM ((Orders
INNER JOIN Customers ON Orders.CustomerID = Customers.CustomerID)
INNER JOIN Shippers ON Orders.OrderID = Shippers.ShipperID);

SELECT Customers.CustomerName, Orders.OrderID
FROM Customers
LEFT JOIN Orders ON Customers.CustomerID =
Orders.CustomerID
ORDER BY Customers.CustomerName;

SELECT Orders.OrderID, Customers.CustomerName, Customers.StateName
FROM Orders
RIGHT JOIN Customers ON Orders. OrderID =
Customers. CustomerID
ORDER BY Orders.OrderID;

SELECT Customers.CustomerName, Orders.OrderID
FROM Customers
FULL OUTER JOIN Orders ON Customers.CustomerID=
Orders.CustomerID
ORDER BY Customers.CustomerName;

SELECT A.CustomerName AS CustomerName1,
B.CustomerName AS CustomerName2, A.Statename
FROM Customers A, Customers B
WHERE A.CustomerID <> B.CustomerID
AND A.Statename = B.StateName
ORDER BY A.Statename;

CREATE PROCEDURE SelectAllCustomers
AS
SELECT * FROM Customers
GO;

EXEC SelectAllCustomers;